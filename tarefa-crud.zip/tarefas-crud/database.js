const sqlite3 = require("sqlite3").verbose();

const db = new sqlite3.Database("./tarefas.db");

db.serialize(() => {
  db.run(`
    CREATE TABLE IF NOT EXISTS tarefas (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      titulo TEXT NOT NULL,
      descricao TEXT,
      data_criacao TEXT DEFAULT CURRENT_TIMESTAMP,
      data_vencimento TEXT,
      prioridade TEXT CHECK(prioridade IN ('baixa','media','alta')),
      status TEXT CHECK(status IN ('pendente','em andamento','concluída')) DEFAULT 'pendente'
    )
  `);
});

module.exports = db;

