const express = require("express");
const cors = require("cors");
const db = require("./database");

const app = express();
app.use(cors());
app.use(express.json());
app.use(express.static("public"));

// CREATE
app.post("/tarefas", (req, res) => {
  const { titulo, descricao, data_vencimento, prioridade } = req.body;

  db.run(
    `INSERT INTO tarefas (titulo, descricao, data_vencimento, prioridade)
     VALUES (?, ?, ?, ?)`,
    [titulo, descricao, data_vencimento, prioridade],
    function (err) {
      if (err) return res.status(500).send(err);
      res.send({ id: this.lastID });
    }
  );
});

// READ
app.get("/tarefas", (req, res) => {
  db.all("SELECT * FROM tarefas", [], (err, rows) => {
    if (err) return res.status(500).send(err);
    res.send(rows);
  });
});

// UPDATE
app.put("/tarefas/:id", (req, res) => {
  const { titulo, descricao, data_vencimento, prioridade, status } = req.body;

  db.run(
    `UPDATE tarefas SET titulo=?, descricao=?, data_vencimento=?, prioridade=?, status=? WHERE id=?`,
    [titulo, descricao, data_vencimento, prioridade, status, req.params.id],
    function (err) {
      if (err) return res.status(500).send(err);
      res.send({ updated: this.changes });
    }
  );
});

// DELETE
app.delete("/tarefas/:id", (req, res) => {
  db.run(`DELETE FROM tarefas WHERE id=?`, req.params.id, function (err) {
    if (err) return res.status(500).send(err);
    res.send({ deleted: this.changes });
  });
});

app.listen(3000, () => console.log("Servidor rodando em http://localhost:3000"));

